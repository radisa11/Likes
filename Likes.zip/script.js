function click();{
    document.querySelector("#count").innerText++;
}   